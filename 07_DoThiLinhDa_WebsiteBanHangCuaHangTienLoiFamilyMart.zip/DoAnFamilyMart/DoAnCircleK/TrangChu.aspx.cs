﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DoAnCircleK
{
    public partial class TrangChu : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Page_PreRender(object sender, EventArgs e)
        {
            Menu menu = (Menu)this.Master.FindControl("menu3");
            if (menu.SelectedValue != "")
            {
                int selectedValue = Convert.ToInt32(menu.SelectedValue);
                string cmdStr = "SELECT MaSP, TenSP, DonGia, HinhAnh FROM SanPham WHERE MaLH = " +
                   selectedValue + " ORDER BY TenSP";
                srcLoai.SelectCommand = cmdStr;
                lstSanPham.DataBind();
            }
        }
        
    }
}