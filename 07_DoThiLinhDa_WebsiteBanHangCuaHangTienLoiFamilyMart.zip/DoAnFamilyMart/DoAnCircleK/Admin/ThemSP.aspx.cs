﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
namespace DoAnCircleK.Admin
{
    public partial class ThemSP : System.Web.UI.Page
    {
        Function func = new Function();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void butAdd_Click(object sender, EventArgs e)
        {
            string conStr = "Data Source=NGUYENMINHAN;Initial Catalog=CircleK;Integrated Security=True";
            SqlConnection con = new SqlConnection(conStr);
            SqlDataAdapter adapt = new SqlDataAdapter();
            adapt.SelectCommand = new SqlCommand("SELECT * FROM SanPham", con);
            DataTable dt = new DataTable();
            adapt.Fill(dt);
            string strFileUpload = "";
            try
            {
                if (upHinh.HasFile)
                {
                    strFileUpload = "~/Images/" + upHinh.FileName;
                    string path = MapPath("/Images/") + upHinh.FileName;
                    upHinh.PostedFile.SaveAs(path);
                }
                adapt.InsertCommand = new SqlCommand("INSERT INTO SanPham VALUES (@MaSP,@TenSP, @DonGia, @TonKho, @DonViTinh, @MaLH, @Images)", con);
                adapt.InsertCommand.Parameters.AddWithValue("@MaSP", txtMaSP.Text);
                adapt.InsertCommand.Parameters.AddWithValue("@TenSP", txtTenSP.Text);
                adapt.InsertCommand.Parameters.AddWithValue("@DonViTinh", drpDVT.SelectedValue);
                adapt.InsertCommand.Parameters.AddWithValue("@DonGia", Convert.ToInt32(txtDonGia.Text));
                adapt.InsertCommand.Parameters.AddWithValue("@MaLH", drpLoai.SelectedValue);
                adapt.InsertCommand.Parameters.AddWithValue("@Images", strFileUpload);
                adapt.InsertCommand.Parameters.AddWithValue("@TonKho", Convert.ToInt32(txtTonKho.Text));
                DataRow row = dt.NewRow();
                row["MaSP"] = func.autoID("SanPham", "MaSP");
                row["TenSP"] = "@TenSP";
                row["DonGia"] = Convert.ToInt32(txtDonGia.Text);
                row["TonKho"] = Convert.ToInt32(txtTonKho.Text);
                row["MaLH"] = "@MaLH";
                row["DonViTinh"] = "@DonViTinh";
                row["Images"] = "@Images";
                dt.Rows.Add(row);
                adapt.Update(dt);
                lblStatus.Text = "Thêm thành công!";
            }
            catch (Exception ex)
            {
                lblStatus.Text = ex.Message;
            }
        
    }
    }
}