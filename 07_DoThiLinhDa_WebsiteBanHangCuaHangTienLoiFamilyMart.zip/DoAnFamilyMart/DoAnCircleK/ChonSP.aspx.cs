﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;
namespace DoAnCircleK
{
    public partial class ChonSP : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["MaSP"] != null)
            {
                string selectedMaSP = Request.QueryString["MaSP"];
                Session["MaSP"] = selectedMaSP;
                LoadSP(selectedMaSP);
            }
        }
        protected void LoadSP(string masp)
        {
            string conStr = WebConfigurationManager.ConnectionStrings["QLBHFamilyMartConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(conStr);
            SqlDataAdapter adapt = new SqlDataAdapter("SELECT MaSP, TenSP, DonGia, HinhAnh FROM SanPham WHERE MaSP=" + "'" + masp + "'", con);
            DataTable dt = new DataTable();
            adapt.Fill(dt);
            if (dt.Rows.Count == 0)
                return;
            lblTenSP.Text = "Tên hàng: " + dt.Rows[0]["TenSP"].ToString();
            lblMaSP.Text = "Mã hàng: " + dt.Rows[0]["MaSP"].ToString();
            lblDonGia.Text = "Đơn giá: " + dt.Rows[0]["DonGia"].ToString();
            imgHinh.ImageUrl = dt.Rows[0]["HinhAnh"].ToString();
            imgHinh.Height = 200;
            imgHinh.Width = 220;
            ViewState["SanPham"] = dt;
        }
       
        public static int TimSP(string masp, DataTable dt)
        {
            int pos = -1;

            // Kiểm tra xem dt có khác null trước khi truy cập các thuộc tính của nó
            if (dt != null && dt.Rows != null)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    // Kiểm tra xem hàng hiện tại và cột "MaSP" có khác null không
                    if (dt.Rows[i]["MaSP"] != null && dt.Rows[i]["MaSP"].ToString().ToLower() == masp.ToLower())
                    {
                        pos = i;
                        break;
                    }
                }
            }

            return pos;
        }
        protected void butInsert_Click(object sender, EventArgs e)
        {
            DataTable dtSP = (DataTable)ViewState["SanPham"];
            DataTable dtGH;
            int Soluong = 0;

            if (Session["GioHang"] == null)    // tao gio hang
            {
                dtGH = new DataTable();
                dtGH.Columns.Add("MaSP");
                dtGH.Columns.Add("TenSP");
                dtGH.Columns.Add("Gia");
                dtGH.Columns.Add("SoLuong");
                dtGH.Columns.Add("TongTien");
            }
            else // lay gio hang tu Session
                dtGH = (DataTable)Session["GioHang"];

            string masp = (string)Session["MaSP"];
            int pos = TimSP(masp, dtGH);

            if (pos != -1)
            {
                Soluong = Convert.ToInt32(dtGH.Rows[pos]["SoLuong"]) + int.Parse(txtSoluong.Text);
                dtGH.Rows[pos]["SoLuong"] = Soluong;
                dtGH.Rows[pos]["TongTien"] = Convert.ToDouble(dtSP.Rows[0]["DonGia"]) * Soluong;
            }
            else
            {
                Soluong = int.Parse(txtSoluong.Text);
                DataRow dr = dtGH.NewRow();
                dr["MaSP"] = dtSP.Rows[0]["MaSP"];
                dr["TenSP"] = dtSP.Rows[0]["TenSP"];
                dr["Gia"] = dtSP.Rows[0]["DonGia"];
                dr["SoLuong"] = Soluong;
                dr["TongTien"] = Convert.ToDouble(dtSP.Rows[0]["DonGia"]) * Soluong;

                dtGH.Rows.Add(dr);
            }

            // Lưu giỏ hàng vào Session
            Session["GioHang"] = dtGH;
            Label2.Text = "Thêm thành công";
        }
    }
}